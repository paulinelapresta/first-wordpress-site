<?php

namespace WordPressPopularPosts\Moment;

/**
 * MomentException
 * @package Moment
 * @author Tino Ehrich (tino@bigpun.me)
 */
class MomentException extends \Exception
{
}